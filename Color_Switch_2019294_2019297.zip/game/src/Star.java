import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
public class Star
{
    private int posY;
    private Image switch_i=new Image(new FileInputStream("assets\\star.png"));
    private ImageView star_iv;
    public  Star(int posY) throws FileNotFoundException
    {
        star_iv=new ImageView(switch_i);
        star_iv.setPreserveRatio(true);
        star_iv.setFitHeight(20);
        star_iv.setX(140);
        star_iv.setY(posY);
    }

    public ImageView getStar_iv() {
        return star_iv;
    }
}

