
import javafx.animation.ScaleTransition;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;


public class Player {
    private double start_posY;
    private int posX;
    private Color color;
    private int radius;
    boolean isAlive;
    Circle playerball;
    public Player(int posX, int start_posY, Color color, int radius)
    {
        this.posX=posX;
        this.start_posY=start_posY;
        this.color=color;
        this.radius=radius;
        isAlive=true;
        playerball=new Circle(posX, start_posY, radius, color);
    }

    public void setColor(Color newcolor)
    {
        playerball.setFill(newcolor);
    }

    public Color getColor()
    {
        return color;
    }


    public double getposY()
    {
        return start_posY;
    }
    public void updateposY()
    {
        start_posY=  playerball.getCenterY();
    }

    public void expand()
    {
        ScaleTransition fill=new ScaleTransition();
        fill.setByX(500);
        fill.setByY(500);
        fill.play();
    }



}
