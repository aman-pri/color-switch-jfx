import javafx.animation.Animation;
import javafx.animation.RotateTransition;
import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.SVGPath;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;

public class Obstacle2 extends Obstacle{

    Group ob2;
    Arc a1, a2, a3, a4;
    colour c1=new colour();
    int posY;
    public Obstacle2(int posY)
    {

        a1=new Arc();
        a2=new Arc();
        a3=new Arc();
        a4=new Arc();



        a1=new Arc();
        a2=new Arc();
        a3=new Arc();
        a4=new Arc();

        a1.setStartAngle(0);
        a2.setStartAngle(90);
        a3.setStartAngle(180);
        a4.setStartAngle(270);

        a1.setStroke(c1.getC1());
        a2.setStroke(c1.getC2());
        a3.setStroke(c1.getC3());
        a4.setStroke(c1.getC4());

        a1.setLength(90);
        a2.setLength(90);
        a3.setLength(90);
        a4.setLength(90);

        a1.setStrokeWidth(15);
        a2.setStrokeWidth(15);
        a3.setStrokeWidth(15);
        a4.setStrokeWidth(15);

        a1.setFill(Color.TRANSPARENT);
        a2.setFill(Color.TRANSPARENT);
        a3.setFill(Color.TRANSPARENT);
        a4.setFill(Color.TRANSPARENT);

        a1.setType(ArcType.OPEN);
        a2.setType(ArcType.OPEN);
        a3.setType(ArcType.OPEN);
        a4.setType(ArcType.OPEN);

        a1.setRadiusX(80);
        a1.setRadiusY(80);
        a2.setRadiusX(80);
        a2.setRadiusY(80);
        a3.setRadiusX(80);
        a3.setRadiusY(80);
        a4.setRadiusX(80);
        a4.setRadiusY(80);

        a1.setCenterX(150);
        a2.setCenterX(150);
        a3.setCenterX(150);
        a4.setCenterX(150);

        ob2=new Group();
        ob2.setLayoutY(posY);

        ob2.getChildren().addAll(a1, a2, a3, a4);
        RotateTransition rt=new RotateTransition();
        rt.setAxis(Rotate.Z_AXIS);
        rt.setByAngle(360);
        rt.setCycleCount(Animation.INDEFINITE);
        rt.setDuration(Duration.millis(5000));
        rt.setNode(ob2);
        rt.play();

    }
}
