import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
public class Switch
{
     private int posY;
     private Image switch_i=new Image(new FileInputStream("assets\\switch.png"));
     private ImageView switch_i_v;
     public  Switch(int posY) throws FileNotFoundException
        {
            switch_i_v=new ImageView(switch_i);
            switch_i_v.setPreserveRatio(true);
            switch_i_v.setFitHeight(20);
            switch_i_v.setX(140);
            switch_i_v.setY(posY);
        }

    public ImageView getSwitch_i_v() {
        return switch_i_v;
    }
}

