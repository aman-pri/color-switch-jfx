import javafx.animation.TranslateTransition;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

public class Obstacle4 {
    private Rectangle r1, r2, r3, r4;
    private colour c1=new colour();
    private int posY;
    public Obstacle4(int posY)
    {
        r1=new Rectangle();
        r2=new Rectangle();
        r3=new Rectangle();
        r4=new Rectangle();

        r1.setFill(c1.getC1());
        r2.setFill(c1.getC2());
        r3.setFill(c1.getC3());
        r4.setFill(c1.getC4());

        r1.setHeight(20);
        r2.setHeight(20);
        r3.setHeight(20);
        r4.setHeight(20);

        r1.setWidth(150);
        r2.setWidth(150);
        r3.setWidth(150);
        r4.setWidth(150);

        r1.setLayoutY(posY);
        r2.setLayoutY(posY);
        r3.setLayoutY(posY);
        r4.setLayoutY(posY);

        r1.setLayoutX(0);
        r2.setLayoutX(150);
        r3.setLayoutX(300);
        r4.setLayoutX(450);

        TranslateTransition tt= new TranslateTransition();
        tt.setByX(-150);
        tt.setAutoReverse(true);
        tt.setCycleCount(20);
        tt.setDuration(Duration.seconds(6));

        tt.setNode(r1);
        tt.setNode(r2);
        tt.setNode(r3);
        tt.setNode(r4);
        tt.play();


    }

}

