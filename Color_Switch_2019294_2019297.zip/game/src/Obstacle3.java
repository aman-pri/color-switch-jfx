import javafx.animation.Animation;
import javafx.animation.RotateTransition;
import javafx.scene.Group;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;

public class Obstacle3 extends Obstacle{

    HBox ob3;
    Group v1;
    Group v2;
    Arc a1, a2, a3, a4, a5, a6, a7, a8;
    colour c1=new colour();
    int posY;
    public Obstacle3(int posY)
    {
        a1=new Arc();
        a2=new Arc();
        a3=new Arc();
        a4=new Arc();

        a5=new Arc();
        a6=new Arc();
        a7=new Arc();
        a8=new Arc();

        a1.setStartAngle(0);
        a2.setStartAngle(90);
        a3.setStartAngle(180);
        a4.setStartAngle(270);

        a1.setStroke(c1.getC1());
        a2.setStroke(c1.getC2());
        a3.setStroke(c1.getC3());
        a4.setStroke(c1.getC4());

        a1.setLength(90);
        a2.setLength(90);
        a3.setLength(90);
        a4.setLength(90);

        a1.setStrokeWidth(15);
        a2.setStrokeWidth(15);
        a3.setStrokeWidth(15);
        a4.setStrokeWidth(15);

        a1.setFill(Color.TRANSPARENT);
        a2.setFill(Color.TRANSPARENT);
        a3.setFill(Color.TRANSPARENT);
        a4.setFill(Color.TRANSPARENT);

        a1.setType(ArcType.OPEN);
        a2.setType(ArcType.OPEN);
        a3.setType(ArcType.OPEN);
        a4.setType(ArcType.OPEN);

        a1.setRadiusX(50);
        a1.setRadiusY(50);
        a2.setRadiusX(50);
        a2.setRadiusY(50);
        a3.setRadiusX(50);
        a3.setRadiusY(50);
        a4.setRadiusX(50);
        a4.setRadiusY(50);



        a5.setStartAngle(0);
        a6.setStartAngle(90);
        a7.setStartAngle(180);
        a8.setStartAngle(270);

        a5.setStroke(c1.getC2());
        a6.setStroke(c1.getC1());
        a7.setStroke(c1.getC4());
        a8.setStroke(c1.getC3());

        a5.setLength(90);
        a6.setLength(90);
        a7.setLength(90);
        a8.setLength(90);

        a5.setStrokeWidth(15);
        a6.setStrokeWidth(15);
        a7.setStrokeWidth(15);
        a8.setStrokeWidth(15);

        a5.setFill(Color.TRANSPARENT);
        a6.setFill(Color.TRANSPARENT);
        a7.setFill(Color.TRANSPARENT);
        a8.setFill(Color.TRANSPARENT);

        a5.setType(ArcType.OPEN);
        a6.setType(ArcType.OPEN);
        a7.setType(ArcType.OPEN);
        a8.setType(ArcType.OPEN);

        a5.setRadiusX(50);
        a5.setRadiusY(50);
        a6.setRadiusX(50);
        a6.setRadiusY(50);
        a7.setRadiusX(50);
        a7.setRadiusY(50);
        a8.setRadiusX(50);
        a8.setRadiusY(50);


        v1=new Group();
        v2=new Group();
        ob3=new HBox();

        v1.getChildren().addAll(a1, a2, a3, a4);
        v2.getChildren().addAll(a5, a6, a7, a8);

        RotateTransition rt=new RotateTransition();
        rt.setAxis(Rotate.Z_AXIS);
        rt.setByAngle(360);
        rt.setCycleCount(Animation.INDEFINITE);
        rt.setDuration(Duration.millis(6500));
        rt.setNode(v1);
        rt.play();

        RotateTransition rt2=new RotateTransition();
        rt2.setAxis(Rotate.Z_AXIS);
        rt2.setByAngle(-360);
        rt2.setCycleCount(Animation.INDEFINITE);
        rt2.setDuration(Duration.millis(6500));
        rt2.setNode(v2);
        rt2.play();

        ob3.getChildren().addAll(v1, v2);
        ob3.setLayoutX(35);
        ob3.setLayoutY(posY);

    }
}
