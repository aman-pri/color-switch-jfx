//AMAN PRIYADARSHI
//2019294
//APEKSHA MAITHANI
//2019297

import javafx.animation.*;
import javafx.application.Application;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Cursor;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.transform.Rotate;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Random;
import java.io.*;
public class Main extends Application
{
    Boolean hitSpace=false;
    public static void main(String[] args)
    {
        launch(args);
    }
    public void start(Stage theStage) throws IOException {

        int FrameSizeX= 300;
        int FrameSizeY=500;
        Group root = new Group();
        Group game_elements=new Group();
        Group pause_elements=new Group();
        Group result_elements=new Group();
        Group l_e=new Group();
        int thisgame;
        char leader_points='0';
        char prev_points='0';
        FileReader prev=new FileReader("assets\\leader.txt");
        int i;
        while ((i=prev.read()) != -1)
            prev_points=((char) i);
        FileReader leader=new FileReader("assets\\leader.txt");
        int j;
        while ((j=leader.read()) != -1)
            leader_points=((char) i);

        Scene scene = new Scene(root, FrameSizeX, FrameSizeY, Color.BLACK);
        Scene game_scene=new Scene(game_elements, FrameSizeX, FrameSizeY, Color.BLACK);
        Scene pause_scene=new Scene(pause_elements, FrameSizeX, FrameSizeY, Color.BLACK);
        Scene result_scene=new Scene(result_elements, FrameSizeX, FrameSizeY, Color.BLACK);
        Scene leaderboard=new Scene(l_e, FrameSizeX, FrameSizeY, Color.BLACK);

        theStage.setScene(scene);
        theStage.show();

        //            COLOR SCHEME          ------------------------------------------------------------
        colour c=new colour();
        Color orange=c.getC1();
        Color violet=c.getC2();
        Color cyan=c.getC3();
        Color yellow=c.getC4();
        ArrayList<Color> colours=new ArrayList<>();
        colours.add(orange);
        colours.add(violet);
        colours.add(cyan);
        colours.add(yellow);

        Image title= new Image(new FileInputStream("assets\\title.png"));
        ImageView ov1 = new ImageView(title);
        root.getChildren().add(ov1);
        ov1.setFitHeight(180);
        ov1.setPreserveRatio(true);
        ov1.setX(60);
        ov1.setY(-30);

        Image l = new Image(new FileInputStream("assets\\leaderboard.jpeg"));
        ImageView lbv=new ImageView(l);
        lbv.setPreserveRatio(true);
        lbv.setFitHeight(100);
        lbv.setLayoutX(100);
        lbv.setLayoutY(40);

        Image h=new Image(new FileInputStream("assets\\home.png"));
        ImageView hv=new ImageView(h);
        hv.setFitHeight(50);
        hv.setPreserveRatio(true);
        hv.setLayoutX(120);
        hv.setLayoutY(300);

        EventHandler home=new EventHandler() {
            @Override
            public void handle(Event event) {
                theStage.setScene(scene);
            }
        };
        hv.setOnMouseClicked(home);

        int lp=Character.getNumericValue(prev_points);
        int pp=Character.getNumericValue(leader_points);
       // System.out.println(lp);
       // System.out.println(pp);
        int d=Math.max(lp, pp);
        //System.out.println(d);
        Text leader1=new Text(Integer.toString(d));
        leader1.setX(135);
        leader1.setY(200);
        leader1.setFill(Color.WHITE);
        leader1.setStrokeWidth(10);
        leader1.setFont(Font.font("verdana", FontWeight.MEDIUM, FontPosture.REGULAR, 40));
        l_e.getChildren().addAll(lbv, hv, leader1);

        Image playbutton_image = new Image(new FileInputStream("assets\\play.png"));
        ImageView playbutton_image_view = new ImageView(playbutton_image);
        playbutton_image_view.setFitHeight(100);
        playbutton_image_view.setPreserveRatio(true);
        playbutton_image_view.setX(100);
        playbutton_image_view.setY(170);
        EventHandler switch_to_game_scene = new EventHandler<MouseEvent>()
        {
            @Override
            public void handle(MouseEvent t) {
                theStage.setScene(game_scene);
            }
        };
        playbutton_image_view.setOnMouseClicked(switch_to_game_scene);
        playbutton_image_view.setCursor(Cursor.OPEN_HAND);
        root.getChildren().add(playbutton_image_view);

        Image obstacle_image = new Image(new FileInputStream("assets\\obstacle.png"));
        ImageView obstacle_image_view = new ImageView(obstacle_image);
        root.getChildren().add(obstacle_image_view);
        obstacle_image_view.setFitHeight(300);
        obstacle_image_view.setPreserveRatio(true);
        obstacle_image_view.setX(0);
        obstacle_image_view.setY(70);
        RotateTransition rotate = new RotateTransition();
        rotate.setAxis(Rotate.Z_AXIS);
        rotate.setByAngle(360);
        rotate.setCycleCount(Animation.INDEFINITE);
        rotate.setDuration(Duration.millis(5000));
        rotate.setNode(obstacle_image_view);
        rotate.play();

        ImageView oiv1 = new ImageView(obstacle_image);
        root.getChildren().add(oiv1);
        oiv1.setFitHeight(65);
        oiv1.setPreserveRatio(true);
        oiv1.setX(88);
        oiv1.setY(-3);
        RotateTransition rotate1 = new RotateTransition();
        rotate1.setAxis(Rotate.Z_AXIS);
        rotate1.setByAngle(360);
        rotate1.setCycleCount(Animation.INDEFINITE);
        rotate1.setDuration(Duration.millis(5000));
        rotate1.setNode(oiv1);
        rotate1.play();

        ImageView oiv2 = new ImageView(obstacle_image);
        root.getChildren().add(oiv2);
        oiv2.setFitHeight(65);
        oiv2.setPreserveRatio(true);
        oiv2.setX(150);
        oiv2.setY(-3);
        RotateTransition rotate2 = new RotateTransition();
        rotate2.setAxis(Rotate.Z_AXIS);
        rotate2.setByAngle(-360);
        rotate2.setCycleCount(Animation.INDEFINITE);
        rotate2.setDuration(Duration.millis(5000));
        rotate2.setNode(oiv2);
        rotate2.play();

        Image exit=new Image(new FileInputStream("assets\\exit.png"));
        ImageView exitv=new ImageView(exit);
        root.getChildren().add(exitv);
        exitv.setPreserveRatio(true);
        exitv.setFitHeight(100);
        exitv.setLayoutY(400);
        exitv.setLayoutX(100);
        EventHandler quit=new EventHandler() {
            @Override
            public void handle(Event event) {
                System.exit(0);
            }
        };

        exitv.setCursor(Cursor.OPEN_HAND);
        exitv.setOnMouseClicked(quit);
        Image load = new Image(new FileInputStream("assets\\load.png"));
        ImageView lv = new ImageView(load);
        root.getChildren().add(lv);
        lv.setFitHeight(130);
        lv.setPreserveRatio(true);
        lv.setX(88);
        lv.setY(275);
        lv.setCursor(Cursor.OPEN_HAND);

        Image lb = new Image(new FileInputStream("assets\\leaderboard.jpeg"));
        ImageView lbv2 = new ImageView(lb);
        root.getChildren().add(lbv2);
        lbv2.setFitHeight(50);
        lbv2.setPreserveRatio(true);
        lbv2.setX(230);
        lbv2.setY(430);
        lbv2.setCursor(Cursor.OPEN_HAND);
        EventHandler lbs=new EventHandler() {
            @Override
            public void handle(Event event) {
                theStage.setScene(leaderboard);
            }
        };
        lbv2.setOnMouseClicked(lbs);
        Image s = new Image(new FileInputStream("assets\\sound.jpeg"));
        ImageView sv = new ImageView(s);
        root.getChildren().add(sv);
        sv.setFitHeight(50);
        sv.setPreserveRatio(true);
        sv.setX(20);
        sv.setY(430);
        sv.setCursor(Cursor.OPEN_HAND);

        Player player=new Player(150, 460, Color.WHITE, 10);
        game_elements.getChildren().add(player.playerball);
        game_scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
            @Override
            public void handle(KeyEvent event) {
                if(event.getCode()==KeyCode.SPACE)
                {
                    hitSpace=true;
                }
            }
        });
        Image star =new Image(new FileInputStream("assets\\star.png"));

        ImageView ov12 = new ImageView(title);
        root.getChildren().add(ov12);
        ov12.setFitHeight(180);
        ov12.setPreserveRatio(true);
        ov12.setX(60);
        ov12.setY(-30);

        ImageView oiv12 = new ImageView(obstacle_image);
        root.getChildren().add(oiv12);
        oiv12.setFitHeight(65);
        oiv12.setPreserveRatio(true);
        oiv12.setX(88);
        oiv12.setY(-3);
        RotateTransition rotate12 = new RotateTransition();
        rotate12.setAxis(Rotate.Z_AXIS);
        rotate12.setByAngle(360);
        rotate12.setCycleCount(Animation.INDEFINITE);
        rotate12.setDuration(Duration.millis(5000));
        rotate12.setNode(oiv12);
        rotate12.play();

        ImageView oiv22 = new ImageView(obstacle_image);
        root.getChildren().add(oiv22);
        oiv22.setFitHeight(65);
        oiv22.setPreserveRatio(true);
        oiv22.setX(150);
        oiv22.setY(-3);
        RotateTransition rotate22 = new RotateTransition();
        rotate22.setAxis(Rotate.Z_AXIS);
        rotate22.setByAngle(-360);
        rotate22.setCycleCount(Animation.INDEFINITE);
        rotate22.setDuration(Duration.millis(5000));
        rotate22.setNode(oiv22);
        rotate22.play();

        ImageView starv3=new ImageView(star);
        starv3.setFitHeight(140);
        starv3.setPreserveRatio(true);
        starv3.setX(80);
        starv3.setY(120);
        pause_elements.getChildren().add(starv3);
        result_elements.getChildren().add(starv3);
        Text stars=new Text();
        stars.setFill(Color.BLACK);
        stars.setFont(Font.font("verdana", FontWeight.SEMI_BOLD, FontPosture.REGULAR, 60));
        stars.setX(135);
        stars.setY(220);
        pause_elements.getChildren().add(stars);
        result_elements.getChildren().add(stars);
        Image homei=new Image(new FileInputStream("assets\\home.png"));
        Image resumei=new Image(new FileInputStream("assets\\resume.png"));
        ImageView resumeiv=new ImageView(resumei);
        resumeiv.setFitHeight(200);
        resumeiv.setPreserveRatio(true);
        resumeiv.setX(50);
        resumeiv.setY(240);
        ImageView homeiv=new ImageView(homei);
        homeiv.setFitHeight(50);
        homeiv.setX(125);
        homeiv.setY(380);
        homeiv.setPreserveRatio(true);
        resumeiv.setOnMouseClicked(switch_to_game_scene);
        resumeiv.setCursor(Cursor.OPEN_HAND);
        EventHandler switch_to_home = new EventHandler<MouseEvent>()
        {
            @Override
            public void handle(MouseEvent t) {
                theStage.setScene(scene);
            }
        };
        homeiv.setOnMouseClicked(switch_to_home);
        homeiv.setCursor(Cursor.OPEN_HAND);

        pause_elements.getChildren().add(ov12);
        pause_elements.getChildren().add(oiv12);
        pause_elements.getChildren().add(oiv22);
        pause_elements.getChildren().add(resumeiv);
        ImageView homeiv2=new ImageView(homei);
        homeiv2.setFitHeight(50);
        homeiv2.setX(125);
        homeiv2.setY(380);
        homeiv2.setPreserveRatio(true);
        result_elements.getChildren().add(ov12);
        result_elements.getChildren().add(oiv12);
        result_elements.getChildren().add(oiv22);
        pause_elements.getChildren().add(homeiv);
        EventHandler to_home = new EventHandler<MouseEvent>()
        {
            @Override
            public void handle(MouseEvent t) {
                theStage.setScene(scene);
            }
        };
        homeiv2.setOnMouseClicked(to_home);
        result_elements.getChildren().add(homeiv2);

        Image pause =new Image(new FileInputStream("assets\\pause.png"));
        ImageView pausev=new ImageView(pause);
        game_elements.getChildren().add(pausev);
        pausev.setFitHeight(30);
        pausev.setPreserveRatio(true);
        pausev.setX(5);
        pausev.setY(465);
        pausev.setCursor(Cursor.OPEN_HAND);

        Image score =new Image(new FileInputStream("assets\\star.png"));
        ImageView scorev=new ImageView(score);
        game_elements.getChildren().add(scorev);
        scorev.setFitHeight(15);
        scorev.setPreserveRatio(true);
        scorev.setX(245);
        scorev.setY(470);
        Text points=new Text();
        points.setX(272);
        points.setY(485);
        points.setFill(Color.WHITE);
        points.setStrokeWidth(10);
        points.setFont(Font.font("verdana", FontWeight.MEDIUM, FontPosture.REGULAR, 20));
        game_elements.getChildren().add(points);
        Random rand =new Random();
        int rand_int1 = rand.nextInt(4);
        Color random=colours.get(rand_int1);
        player.setColor(random);
        Switch switch1_i=new Switch(0);
        Switch switch2_i=new Switch(-350);
        Switch switch3_i=new Switch(-650);
        ImageView switch1=switch1_i.getSwitch_i_v();
        ImageView switch2=switch2_i.getSwitch_i_v();
        ImageView switch3=switch3_i.getSwitch_i_v();
        Obstacle1 o1=new Obstacle1();
        HBox ob1=new HBox();
        ob1.getChildren().addAll(o1.getR1(), o1.getR2(), o1.getR3(), o1.getR4(), o1.getR5(), o1.getR6(), o1.getR7(), o1.getR8());
        o1.move(ob1);
        ArrayList<Rectangle> rectangles=new ArrayList<>();
        rectangles.add(o1.getR1());
        rectangles.add(o1.getR2());
        rectangles.add(o1.getR3());
        rectangles.add(o1.getR4());
        rectangles.add(o1.getR5());
        rectangles.add(o1.getR6());
        rectangles.add(o1.getR7());
        rectangles.add(o1.getR8());

        Obstacle2 ob2= new Obstacle2(-500);
        Obstacle3 ob3= new Obstacle3(-850);
        Obstacle4 ob4=new  Obstacle4(100);
        Star star1_i=new Star(-200);
        Star star2_i=new Star(-500);
        Star star3_i=new Star(-900);
        ImageView star1=star1_i.getStar_iv();
        ImageView star2=star2_i.getStar_iv();
        ImageView star3=star3_i.getStar_iv();
        game_elements.getChildren().addAll(switch1, ob1, star1);
        game_elements.getChildren().addAll(switch2, ob2.ob2, star2);
        game_elements.getChildren().addAll(switch3, ob3.ob3, star3);

        Rectangle r1=new Rectangle();
        r1.setWidth(90);
        r1.setHeight(20);

        AnimationTimer game_timer=new AnimationTimer()
        {

            int starlist=1;
            int starcount=0;
            double time=0;
            double gravity=30;
            double velY=0;
            double newvelY=0;
            double dY=0;
            boolean Switch1collected=false;
            boolean Switch2collected=false;
            boolean Switch3collected=false;
            boolean Star1collected=false;
            boolean Star2collected=false;
            boolean Star3collected=false;
            FileWriter x=new FileWriter("new.txt");
            @Override
            public void handle(long now)
            {
                    velY += 0.5 * gravity * time * time;
                    dY = velY;

                    if((int)player.playerball.getLayoutY()>20)
                    {
                        player.isAlive=false;
                    }

                //RESETTING CONFIGURATIONS
                    if(star3.getLayoutY()>1230) 
                    {
                        switch1.setLayoutY(0);
                        ob1.setLayoutY(-150);
                        star1.setLayoutY(-140);
                        switch2.setLayoutY(-160);
                        ob2.ob2.setLayoutY(-500);
                        star2.setLayoutY(-200);
                        switch3.setLayoutY(-250);
                        ob3.ob3.setLayoutY(-850);
                        star3.setLayoutY(-250);
                        Switch1collected=false;
                        Switch2collected=false;
                        Switch3collected=false;
                        Star1collected=false;
                        Star2collected=false;
                        Star3collected=false;
                        star1.setOpacity(100);
                        star2.setOpacity(100);
                        star3.setOpacity(100);
                        switch1.setOpacity(100);
                        switch2.setOpacity(100);
                        switch3.setOpacity(100);
                    }

                        if (switch1.getBoundsInParent().intersects(player.playerball.getBoundsInParent())&&!Switch1collected)
                        {
                            Switch1collected=true;
                            switch1.setOpacity(0);
                            int rand_int2 = rand.nextInt(4);
                            player.playerball.setFill(colours.get(rand_int2));
                        }
                        if (switch2.getBoundsInParent().intersects(player.playerball.getBoundsInParent())&&!Switch2collected)
                        {
                            Switch2collected=true;
                            switch2.setOpacity(0);
                            int rand_int2 = rand.nextInt(4);
                            player.playerball.setFill(colours.get(rand_int2));
                        }
                        if (switch3.getBoundsInParent().intersects(player.playerball.getBoundsInParent())&&!Switch3collected)
                        {
                            Switch3collected=true;
                            switch3.setOpacity(0);
                            int rand_int2 = rand.nextInt(4);
                            player.playerball.setFill(colours.get(rand_int2));
                        }

                        if (star1.getBoundsInParent().intersects(player.playerball.getBoundsInParent())&&!Star1collected)
                        {
                            starcount += 1;
                            star1.setOpacity(0);
                            Star1collected=true;
                            stars.setText(Integer.toString(starcount));
                            points.setText(Integer.toString(starcount));
                        }
                        if (star2.getBoundsInParent().intersects(player.playerball.getBoundsInParent())&&!Star2collected)
                        {
                            starcount += 1;
                            star2.setOpacity(0);
                            Star2collected=true;
                            stars.setText(Integer.toString(starcount));
                            points.setText(Integer.toString(starcount));
                        }
                        if (star3.getBoundsInParent().intersects(player.playerball.getBoundsInParent())&&!Star3collected)
                        {
                            starcount += 1;
                            star3.setOpacity(0);
                            Star3collected=true;
                            stars.setText(Integer.toString(starcount));
                            points.setText(Integer.toString(starcount));
                        }
                        if(o1.getR1().getBoundsInParent().intersects(player.playerball.getBoundsInParent()))
                        {
                            //System.out.println("1");
                            if(o1.getR1().getFill()!=player.playerball.getFill())
                            {
                                player.isAlive=false;
                            }
                        }
                        if(rectangles.get(1).getBoundsInParent().intersects(player.playerball.getBoundsInParent()))
                        {
                            //System.out.println("1");

                            if(o1.getR2().getFill()!=player.playerball.getFill())
                            {
                                player.isAlive=false;
                            }
                        }
                        if(rectangles.get(2).getBoundsInParent().intersects(player.playerball.getBoundsInParent()))
                        {
                            //System.out.println("1");

                            if(o1.getR3().getFill()!=player.playerball.getFill())
                            {
                                player.isAlive=false;
                            }
                        }
                        if(rectangles.get(3).getBoundsInParent().intersects(player.playerball.getBoundsInParent()))
                        {
                            //System.out.println("1");

                            if(o1.getR3().getFill()!=player.playerball.getFill())
                            {
                                player.isAlive=false;
                            }
                        }
                        if(rectangles.get(4).getBoundsInParent().intersects(player.playerball.getBoundsInParent()))
                        {
                            //System.out.println("1");

                            if(o1.getR5().getFill()!=player.playerball.getFill())
                            {
                                player.isAlive=false;
                            }
                        }
                        if(rectangles.get(5).getBoundsInParent().intersects(player.playerball.getBoundsInParent()))
                        {
                            //System.out.println("1");

                            if(o1.getR6().getFill()!=player.playerball.getFill())
                            {
                                player.isAlive=false;
                            }
                        }
                        if(rectangles.get(6).getBoundsInParent().intersects(player.playerball.getBoundsInParent()))
                        {
                            //System.out.println("1");

                            if(o1.getR7().getFill()!=player.playerball.getFill())
                            {
                                player.isAlive=false;
                            }
                        }
                        if(rectangles.get(7).getBoundsInParent().intersects(player.playerball.getBoundsInParent()))
                        {
                           // System.out.println("1");

                            if(o1.getR8().getFill()!=player.playerball.getFill())
                            {
                                player.isAlive=false;
                            }
                        }


                if(ob2.a1.getBoundsInParent().intersects(player.playerball.getBoundsInParent()))
                        {
                            if(player.getColor()!=ob2.a1.getFill())
                            {
                                player.isAlive=false;
                            }
                        }
                        if(ob2.a2.getBoundsInParent().intersects(player.playerball.getBoundsInParent()))
                        {
                            if(player.getColor()!=ob2.a2.getFill())
                            {
                                player.isAlive=false;
                            }
                        }
                        if(ob2.a3.getBoundsInParent().intersects(player.playerball.getBoundsInParent()))
                        {
                            if(player.getColor()!=ob2.a3.getFill())
                            {
                                player.isAlive=false;
                            }
                        }
                        if(ob2.a4.getBoundsInParent().intersects(player.playerball.getBoundsInParent()))
                        {
                            if(player.getColor()!=ob2.a4.getFill())
                            {
                                player.isAlive=false;
                            }
                        }

                        if(ob3.a1.getBoundsInParent().intersects(player.playerball.getBoundsInParent()))
                        {
                            if(player.getColor()!=ob3.a1.getFill())
                            {
                                player.isAlive=false;
                            }
                                }
                        if(ob3.a2.getBoundsInParent().intersects(player.playerball.getBoundsInParent()))
                        {
                            if(player.getColor()!=ob3.a2.getFill())
                            {
                                player.isAlive=false;
                            }
                        }
                        if(ob3.a3.getBoundsInParent().intersects(player.playerball.getBoundsInParent()))
                        {
                            if(player.getColor()!=ob3.a3.getFill())
                            {
                                player.isAlive=false;
                            }
                        }
                        if(ob3.a4.getBoundsInParent().intersects(player.playerball.getBoundsInParent()))
                        {
                            if(player.getColor()!=ob3.a4.getFill())
                            {
                                player.isAlive=false;
                            }
                        }
                        if(ob3.a5.getBoundsInParent().intersects(player.playerball.getBoundsInParent()))
                        {
                            if(player.getColor()!=ob3.a5.getFill())
                            {
                                player.isAlive=false;
                            }
                        }
                        if(ob3.a6.getBoundsInParent().intersects(player.playerball.getBoundsInParent()))
                        {
                            if(player.getColor()!=ob3.a6.getFill())
                            {
                                player.isAlive=false;
                            }
                        }
                        if(ob3.a7.getBoundsInParent().intersects(player.playerball.getBoundsInParent()))
                        {
                            if(player.getColor()!=ob3.a7.getFill())
                            {
                                player.isAlive=false;
                            }
                        }
                        if(ob3.a8.getBoundsInParent().intersects(player.playerball.getBoundsInParent()))
                        {
                            if(player.getColor()!=ob3.a8.getFill())
                            {
                                player.isAlive=false;
                            }
                        }

                    if(!player.isAlive)
                            {
                                theStage.setScene(result_scene);
                                try {
                                    x.write(Integer.toString(starcount));
                                } catch (IOException e) {
                                    e.printStackTrace();
                                }
//                                try {
//                                    x.close();
//                                } catch (IOException e) {
//                                    e.printStackTrace();
//                                }
//                                System.out.println("WRITTEN");
                                this.stop();
                            }
                if (hitSpace) {
                        if (player.playerball.getLayoutY() > -300) {
                            velY = -5;
                            time = .13;
                            hitSpace = false;
                            ob1.setLayoutY(ob1.getLayoutY()+20);
                            ob2.ob2.setLayoutY(ob2.ob2.getLayoutY()+20);
                            ob3.ob3.setLayoutY(ob3.ob3.getLayoutY()+20);

                            star1.setLayoutY((star1.getLayoutY()+20));
                            star2.setLayoutY((star2.getLayoutY()+20));
                            star3.setLayoutY((star3.getLayoutY()+20));

                            switch1.setLayoutY((switch1.getLayoutY()+20));
                            switch2.setLayoutY((switch2.getLayoutY()+20));
                            switch3.setLayoutY((switch3.getLayoutY()+20));
                        }
                    }
                    player.playerball.setLayoutY(player.playerball.getLayoutY() + dY);
                    if(starcount<10)
                    {
                        time+=0.0001;
                        player.isAlive=true;
                    }

                    else
                    {
                        time+=(time*1000)+0.001;
                        player.isAlive=true;
                    }
            }
        };

        Image starti=new Image(new FileInputStream("assets\\start.png"));
        ImageView startiv=new ImageView(starti);
        startiv.setLayoutY(390);
        startiv.setLayoutX(65);
        game_elements.getChildren().add(startiv);
        EventHandler startgame = new EventHandler<MouseEvent>()
        {
            @Override
            public void handle(MouseEvent t) {
                game_elements.getChildren().remove(startiv);
                game_timer.start();
            }
        };
        EventHandler switch_to_pause_screen = new EventHandler<MouseEvent>()
        {
            @Override
            public void handle(MouseEvent t) {
                theStage.setScene(pause_scene);
                game_timer.stop();
            }
        };
        pausev.setOnMouseClicked(switch_to_pause_screen);
        startiv.setFitHeight(200);
        startiv.setPreserveRatio(true);
        startiv.setX(0);
        startiv.setOnMouseClicked(startgame);
        startiv.setCursor(Cursor.OPEN_HAND);
        theStage.show();
    }
}
