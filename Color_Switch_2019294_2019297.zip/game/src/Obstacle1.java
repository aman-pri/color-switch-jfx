import javafx.animation.TranslateTransition;
import javafx.scene.layout.HBox;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.SVGPath;
import javafx.util.Duration;
import java.util.ArrayList;
public class Obstacle1 extends Obstacle {
   // private HBox ob1;
    private Rectangle r1, r2, r3, r4, r5, r6, r7, r8;
    ArrayList<Rectangle> rectangles;
    colour c1=new colour();
    int posY;
    public Obstacle1()
    {
        r1=new Rectangle();
        r2=new Rectangle();
        r3=new Rectangle();
        r4=new Rectangle();
        r5=new Rectangle();
        r6=new Rectangle();
        r7=new Rectangle();
        r8=new Rectangle();

        r1.setFill(c1.getC1());
        r2.setFill(c1.getC2());
        r3.setFill(c1.getC3());
        r4.setFill(c1.getC4());
        r5.setFill(c1.getC1());
        r6.setFill(c1.getC2());
        r7.setFill(c1.getC3());
        r8.setFill(c1.getC4());
        r1.setHeight(20);
        r2.setHeight(20);
        r3.setHeight(20);
        r4.setHeight(20);
        r5.setHeight(20);
        r6.setHeight(20);
        r7.setHeight(20);
        r8.setHeight(20);
        r1.setWidth(90);
        r2.setWidth(90);
        r3.setWidth(90);
        r4.setWidth(90);
        r5.setWidth(90);
        r6.setWidth(90);
        r7.setWidth(90);
        r8.setWidth(90);

    }

    public Rectangle getR1()
    {
        return r1;
    }
    public Rectangle getR2() {
        return r2;
    }
    public Rectangle getR3() {
        return r3;
    }
    public Rectangle getR4() {
        return r4;
    }
    public Rectangle getR5() {
        return r5;
    }
    public Rectangle getR6() {
        return r6;
    }
    public Rectangle getR7() {
        return r7;
    }
    public Rectangle getR8() {
        return r8;
    }
    public ArrayList<Rectangle> getList()
    {
        return rectangles;
    }
    public void move(HBox h)
    {
        TranslateTransition tt= new TranslateTransition();
        tt.setByX(-300);
        tt.setAutoReverse(true);
        tt.setCycleCount(20);
        tt.setDuration(Duration.seconds(6));
        tt.setNode(h);
        tt.play();
    }
}
