import javafx.scene.paint.Color;

public class colour {
    private Color c1=Color.rgb(247, 103, 37);
    private Color c2=Color.rgb(157, 41, 122);
    private Color c3=Color.rgb(69, 186, 204);
    private Color c4=Color.rgb(249,200, 12);

    public Color getC1() {
        return c1;
    }

    public Color getC2() {
        return c2;
    }

    public Color getC3() {
        return c3;
    }

    public Color getC4() {
        return c4;
    }
}
